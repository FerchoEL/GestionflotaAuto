<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Vehiculo extends Model
{
    protected static function booted(): void
    {
        static::saving(function (self $vehiculo): void {
            if (! $vehiculo->isDirty('marca_vehiculo_id')) {
                return;
            }

            if (! $vehiculo->marca_vehiculo_id) {
                $vehiculo->marca = null;

                return;
            }

            $vehiculo->marca = DB::table('marca_vehiculos')
                ->where('id', $vehiculo->marca_vehiculo_id)
                ->value('nombre');
        });
    }

    protected $fillable = [
        'tipo_vehiculo_id',
        'estatus_id',
        'marca_vehiculo_id',
        'tipo_combustible',
        'transmision',
        'numero_economico',
        'placas',
        'vin',
        'marca',
        'modelo',
        'anio',
        'color',
        'capacidad_tanque_litros',
        'rendimiento_optimo_km_l',
        'tolerancia_pct',
        'activo',
    ];

    public function getDisplayNameAttribute(): string
    {
        $numeroEconomico = trim((string) $this->numero_economico);
        $placas = trim((string) $this->placas);

        if ($numeroEconomico !== '' && $placas !== '') {
            return "{$numeroEconomico} - {$placas}";
        }

        return $numeroEconomico !== '' ? $numeroEconomico : $placas;
    }

    public function getMarcaAttribute($value): ?string
    {
        return $this->marcaVehiculo?->nombre ?? $value;
    }

    public function getUsuariosAsignadosTextoAttribute(): string
    {
        $usuarios = $this->choferes
            ->filter(function ($chofer) {
                if (! $chofer->activo) {
                    return false;
                }

                return $chofer->fecha_fin === null || $chofer->fecha_fin->greaterThanOrEqualTo(now()->startOfDay());
            })
            ->sortByDesc('fecha_inicio')
            ->map(fn ($chofer) => trim((string) $chofer->chofer?->name))
            ->filter()
            ->unique()
            ->values();

        return $usuarios->isNotEmpty()
            ? $usuarios->join(', ')
            : '-';
    }

    public function getUsuarioResponsableTextoAttribute(): string
    {
        return trim((string) $this->responsableActivo?->responsable?->name) ?: '-';
    }
    
    public function tipoVehiculo()
    {
        return $this->belongsTo(TipoVehiculo::class, 'tipo_vehiculo_id', 'id');
    }

    public function marcaVehiculo()
    {
        return $this->belongsTo(MarcaVehiculo::class, 'marca_vehiculo_id', 'id');
    }

    /* public function departamento()
    {
        return $this->belongsTo(Departamento::class, 'departamento_id', 'id');
    }

    public function localidad()
    {
        return $this->belongsTo(Localidad::class, 'localidad_id', 'id');
    } */

    public function estatus()
    {
        return $this->belongsTo(VehiculoEstatus::class, 'estatus_id', 'id');
    }

    public function choferes()
    {
        return $this->hasMany(VehiculoChofer::class, 'vehiculo_id', 'id');
    }

    public function responsables()
    {
        return $this->hasMany(VehiculoResponsable::class, 'vehiculo_id', 'id');
    }
    public function responsableActivo()
    {
        return $this->hasOne(VehiculoResponsable::class)
            ->where('activo', true)
            ->orderByDesc('fecha_inicio');
    }

    public function cargas()
    {
        return $this->hasMany(CargaCombustible::class, 'vehiculo_id', 'id');
    }

    public function rendimientos()
    {
        return $this->hasMany(Rendimiento::class, 'vehiculo_id', 'id');
    }

    public function documentos()
    {
        return $this->hasMany(VehiculoDocumento::class, 'vehiculo_id', 'id');
    }

    public function fondeos()
    {
        return $this->hasMany(Fondeo::class, 'vehiculo_id', 'id');
    }

    public function fondeoConfigActual()
    {
        return $this->hasOne(VehiculoFondeoConfig::class, 'vehiculo_id', 'id')
            ->where('activo', true);
    }

    public function fondeoConfigs()
    {
        return $this->hasMany(VehiculoFondeoConfig::class, 'vehiculo_id', 'id');
    }

    
    public function departamentos()
    {
        return $this->hasMany(VehiculoDepartamento::class);
    }

    public function departamentoActivo()
    {
        return $this->hasOne(VehiculoDepartamento::class)
            ->where('activo', true)
            ->orderByDesc('fecha_inicio');
    }

    public function localidades()
    {
        return $this->hasMany(VehiculoLocalidad::class);
    }

    public function localidadActiva()
    {
        return $this->hasOne(VehiculoLocalidad::class)
            ->where('activo', true)
            ->orderByDesc('fecha_inicio');
    }
    public function tarjetas()
    {
        return $this->hasMany(VehiculoTarjeta::class);
    }

    public function tarjetaActiva()
    {
        return $this->hasOne(VehiculoTarjeta::class)
            ->where('activo', true)
            ->orderByDesc('fecha_inicio')   // ✅ importante
            ->orderByDesc('id');
    }
    public function choferActivo()
    {
        return $this->hasOne(\App\Models\VehiculoChofer::class, 'vehiculo_id', 'id')
            ->where('activo', true)
            ->orderByDesc('fecha_inicio');
    }

    public function choferesActivos()
    {
        return $this->hasMany(\App\Models\VehiculoChofer::class, 'vehiculo_id', 'id')
            ->where('activo', true)
            ->where(function ($query) {
                $query->whereNull('fecha_fin')
                    ->orWhere('fecha_fin', '>=', now()->toDateString());
            })
            ->orderByDesc('fecha_inicio');
    }
    public function cuentasAnaliticas()
    {
        return $this->hasMany(\App\Models\VehiculoCuentaAnalitica::class, 'vehiculo_id', 'id');
    }

    public function cuentaAnaliticaActiva()
    {
        return $this->hasOne(\App\Models\VehiculoCuentaAnalitica::class, 'vehiculo_id', 'id')
            ->where('activo', true)
            ->orderByDesc('fecha_inicio')
            ->orderByDesc('id');
    }

}
