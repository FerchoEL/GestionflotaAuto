<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
         Schema::create('fondeos', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('vehiculo_id');
            $table->unsignedBigInteger('fondeado_por_user_id')->nullable();

            $table->decimal('litros_fondeados', 10, 2);
            $table->decimal('importe_fondeado', 12, 2)->nullable();

            $table->dateTime('fecha_fondeado');

            $table->string('comentario')->nullable();

            $table->timestamps();

            $table->foreign('vehiculo_id')
                ->references('id')
                ->on('vehiculos')
                ->cascadeOnDelete();

            $table->foreign('fondeado_por_user_id')
                ->references('id')
                ->on('users')
                ->nullOnDelete();

            $table->index(['vehiculo_id', 'fecha_fondeado']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('fondeos');
    }
};
